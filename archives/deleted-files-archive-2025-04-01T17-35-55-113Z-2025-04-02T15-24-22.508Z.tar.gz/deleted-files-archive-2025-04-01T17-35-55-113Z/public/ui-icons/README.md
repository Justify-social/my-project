# DEPRECATED

This directory is deprecated. Please use the single source of truth at `/public/static/` instead.

This directory will be removed on 2025-06-30.

All code should reference files in the `/public/static/` directory.
