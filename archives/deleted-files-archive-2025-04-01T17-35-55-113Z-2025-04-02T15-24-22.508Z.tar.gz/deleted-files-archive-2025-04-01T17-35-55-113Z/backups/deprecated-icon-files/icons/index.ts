/**
 * @deprecated This direct import path has been moved.
 * Please import from '@/components/ui/atoms/icons' instead.
 * This redirect will be removed in a future version.
 */

export * from '@/components/ui/atoms/icons'; 