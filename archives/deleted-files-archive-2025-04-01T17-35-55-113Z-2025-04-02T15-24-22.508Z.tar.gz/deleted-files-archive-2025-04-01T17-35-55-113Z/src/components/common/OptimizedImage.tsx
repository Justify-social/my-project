/**
 * @deprecated This component has been moved to src/components/ui/atoms/image/OptimizedImage.tsx
 * Please import from '@/components/ui/atoms/image' instead.
 */

import { OptimizedImage } from '@/components/ui/atoms/image'

export type { OptimizedImageProps };
export const OptimizedImage = UIOptimizedImage;
export default OptimizedImage; 