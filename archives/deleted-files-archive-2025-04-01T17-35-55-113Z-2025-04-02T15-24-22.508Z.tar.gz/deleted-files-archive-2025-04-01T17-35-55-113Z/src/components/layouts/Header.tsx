/**
 * @deprecated This component has been moved to src/components/ui/organisms/navigation/header
 * Please import from '@/components/ui/organisms/navigation/header' instead.
 */

import { Header } from '@/components/ui/organisms/navigation/header/Header'

export { Header };
export default Header;