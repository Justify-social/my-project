/**
 * Card Component - DEPRECATED LOCATION
 * 
 * ⚠️ DEPRECATED: This location is deprecated. Please import from '@/components/ui/organisms/card' instead.
 * 
 * This forwarding file will be removed in a future update. Update your imports to use the organisms path.
 */

export * from '../../organisms/card';
