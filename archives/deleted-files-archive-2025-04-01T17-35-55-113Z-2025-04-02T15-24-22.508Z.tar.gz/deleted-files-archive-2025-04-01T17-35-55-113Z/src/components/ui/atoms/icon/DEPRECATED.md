# DEPRECATED

These icon files are deprecated. Please use the single source of truth at `/public/static/` instead.

This directory will be maintained for backward compatibility, but new icons should be added directly to 
`/public/static/icon-registry.json` and `/public/static/icon-url-map.json`.

All new code should reference files in the canonical location.
