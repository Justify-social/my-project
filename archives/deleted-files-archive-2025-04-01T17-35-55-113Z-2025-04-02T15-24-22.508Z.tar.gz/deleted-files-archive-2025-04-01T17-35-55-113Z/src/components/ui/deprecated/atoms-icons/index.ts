/**
 * DEPRECATED - This file forwards the atoms/icon component for backward compatibility.
 * Please update imports to use '@/components/ui/atoms/icon' instead.
 * This forwarding module will be removed in a future update.
 */

export { Icon } from '@/components/ui/atoms/icon';
export * from '@/components/ui/atoms/icon/types'; 