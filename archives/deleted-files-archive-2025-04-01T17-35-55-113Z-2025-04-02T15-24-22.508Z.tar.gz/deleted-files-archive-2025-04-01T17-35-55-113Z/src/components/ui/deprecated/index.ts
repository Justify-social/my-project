/**
 * DEPRECATED COMPONENTS
 * 
 * These components are provided for backward compatibility
 * during the shadcn migration. They should be replaced with
 * the new shadcn components as soon as possible.
 */

// Icon components
export * from './atoms-icons';

// Navigation components
export * from './organisms-navigation/header';
export * from './organisms-navigation/sidebar';

// Feedback components 
export * from './molecules-feedback'; 