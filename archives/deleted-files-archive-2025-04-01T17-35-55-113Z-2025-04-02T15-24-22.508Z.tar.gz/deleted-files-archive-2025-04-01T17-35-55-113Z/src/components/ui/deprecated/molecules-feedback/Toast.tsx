'use client';

import React from 'react';
import { Toaster } from "@/components/ui/molecules/sonner/Sonner";

// This is a temporary implementation to fix import issues
// It redirects to the shadcn toaster component
export interface ToastProps {
  className?: string;
  children?: React.ReactNode;
  [key: string]: any;
}

export const Toast = (props: ToastProps) => {
  // Simply use the shadcn toaster component
  return <Toaster />;
};

export const ToastProvider = Toast;

export default Toast; 